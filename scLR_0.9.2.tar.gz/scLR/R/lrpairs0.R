#' A dataset storing ligand-receptor pairs for comparisons
#'
#' @description A dataset storing ligand-receptor pairs for comparisons
#'
#' @format A data frame with 3239 rows (LR pairs) and 2 columns:
#' \describe{
#'   \item{ligand}{ligand name}
#'   \item{receptor}{receptor name}
#' }
"lrpairs0"
