#' Test dysregulated ligand-receptor interactions at small sample sizes (count matrix)
#' @description A function to test dysregulated ligand-receptor interactions from single cell transcriptomics
#' between two conditions.
#' @importFrom Matrix rowSums head tail
#' @importFrom limma lmFit eBayes
#' @importFrom stats rchisq quantile runif t.test sd bw.SJ pnorm p.adjust cor.test
#' @importFrom parallel makeCluster clusterExport parApply stopCluster clusterEvalQ
#' @importFrom dplyr distinct
#' @importFrom DESeq2 DESeqDataSetFromMatrix estimateSizeFactors counts


#' @param countmatrix Input. Count matrix/dataframe with gene names.
#' @param cellinfo Input. Information for each cell, including their sampleIDs, conditions, and cell types.
#' @param lrpairs.sample  Input. A K by 2 matrix/dataframe to show names of ligand-receptor gene pairs
#' which will be compared between two samples.
#' @param low.filter Input. Pre-exclude gene pairs with the averages of gene expressions across replicates
#' less than \emph{low.filter}. The default is 1. If NULL, no LR gene pairs are pre-excluded.
#' @param p.adjust.method Input (optional). The default is "BH". Other methods include
#  "holm", "hochberg", "hommel", "bonferroni", "BH", "BY" and "fdr" (Please refer to stats::p.adjust).
#' @param Brep  Input (optional). Number of Monte-Carlo simulation replications (m). The default is 1000.
#' @param Brep0 Input (optional). Number of Monte-Carlo simulation replications in the first-stage (rough) selection.
#' The default is 200. If Brep0 = Brep, no second-stage selection.
#' @param pv0   Input (optional). Prespecified p-value in the first-stage (rough) selection.
#' The default is 0.05.
#' @param p.filter   Input (optional). The threshold, p.filter, is used to determine which ligand-receptor gene pairs
#' will not be compared. For each LR gene pair, if the average of gene expressions in one of LR genes in both samples
#' are less than the (p.filter)-quantiles of gene expressions (within same cell type),
#' the LR gene pair with the low-expressed gene will not be compared.
#' The default is 0.05.
#' @param show.all   Input (optional). A logical indicator whether or not to show
#' the results of the ligand-receptor gene pairs with lowly expressed genes. The default is FALSE,
#' showing only the results of the ligand-receptor gene pairs without lowly expressed genes.
#' @param parallel.use   Input (optional). A logical indicator whether or not to use a parallel computation.
#' The default is FALSE, i.e., a parallel computation will not be used.
#' @param cpucores   Input (optional). \emph{cpucores} CPU cores (default = 2) are used for parallel computation.
#' @param zero.impute Input (optional). A logical indicator whether zero imputation is performed or not.
#' If it is TRUE, when all the gene expressions of ligands or receptors are zeros in one sample,
#' zeros will be imputed with small non-negative values which are generated from a uniform distribution,
#' U(0, min(non-zero gene expressions)/2).
#' @param adjust Input (optional). The bandwidth h estimated by R function bw.SJ is adjusted by adjust * h.
#' The default of \emph{adjust} is 3.
#' @param rhos Input (optional). The correlations in ligand-receptor pairs.
#' The default is NULL, assuming zero correlations for all ligand-receptor pairs.
#' Users can assume an overall correlation value for all ligand-receptor pairs, e.g, rhos = 0.1; or
#' consider Pearson correlation coefficient estimates for the correlations (rhos = "est"). Nevertheless,
#' due to the limited sample sizes, most of the estimates are not robust.
#' Thus, they will be forced to zeros if the p-values > 0.01 obtained by R function cor.test().


#' @return \item{obs.xy.diff}{Observed difference of mean of LR between two samples (sample 2 minus sample 1)}
#' @return \item{null.diff.sd}{Standard deviation of mean difference of LR under null hypothesis}
#' @return \item{diff.stat}{obs.xy.diff is divided by null.diff.sd}
#' @return \item{pvalue}{P-value}
#' @return \item{stage}{Which stage gene pairs pass to}
#' @return \item{adj.p}{Adjusted p-value of scLR for multiple comparison}
#' @return \item{Welch.t.*}{Statistic, pooled standard error, and p-value of Welch's t-test}
#' @return \item{adj.t.p}{Adjusted p-value of Welch's t-test for multiple comparison}
#' @return \item{limma.Lg.*}{P-value and logFC for each gene expression of ligands}
#' @return \item{limma.Rg.*}{P-value and logFC for each gene expression of receptors}
#' @return \item{adj.limma.Lg.p}{Adjusted p-value for each gene expression of ligands}
#' @return \item{adj.limma.Rg.p}{Adjusted p-value for each gene expression of receptors}
#' @return \item{mu.matrix1}{Sample mean for each gene in sample 1}
#' @return \item{mu.matrix2}{Sample mean for each gene in sample 2}
#' @return \item{sigma.matrix1}{Posterior residual standard deviation for each gene in sample 1}
#' @return \item{sigma.matrix2}{Posterior residual standard deviation for each gene in sample 2}
#' @return \item{pv.matrix}{P-values for each gene of all cell types using limma}
#' @return \item{lofFC.matrix}{log fold change for each gene of all cell types using limma}

#' @examples # A simulated data to compare LR pairs between two conditions: TX1 and TX2.
#' @examples # 3 replicates each condition.
#' @examples # 1000 genes and 100 cells (5 cell types, 20 cells each) each replicate.
#' @examples # 10 ligand-receptor gene pairs across 5 cell types are compared between TX1 and TX2.
#'
#' @examples set.seed(2021)
#' @examples cellinfo <- data.frame(sampleID = factor(paste0("s", rep(1:6, each=100))),
#' @examples                       condition = factor(paste0("tx", rep(1:2, each=300))),
#' @examples                       cellcluster = factor(paste0("cc", rep(rep(1:5, each=20), 6))) )
#' @examples G <- 1000; n <- 600 # 1000 genes, 600 cells
#' @examples # Data are generated from NB dist.
#' @examples NB_cell <- function(j) rnbinom(G, size = 0.1, mu = rgamma(G, shape = 2, rate = 2))
#' @examples countmatrix <- as(sapply(1:n, NB_cell),"sparseMatrix"); rownames(countmatrix) <- paste0("g", 1:1000)
#' @examples # Names of 10 ligand-receptor pairs
#' @examples lrpairs.sample <- data.frame(ligand=paste0("g", sample(1:1000, 10)),
#' @examples                             receptor=paste0("g", sample(1:1000, 10)) )
#' @examples output <- scLR(countmatrix, cellinfo, lrpairs.sample, low.filter = 1)
#' @examples head(output$Rs, 20)

#' @export

scLR <- function(countmatrix, cellinfo, lrpairs.sample, low.filter = 1, p.adjust.method = "BH",
                  Brep = 1000, Brep0 = 200, pv0 = 0.05, p.filter = 0.05, show.all = FALSE,
                  parallel.use = FALSE, cpucores = 2, zero.impute = TRUE, adjust = 3, rhos = NULL) {

  colnames(cellinfo) <- c("sampleID", "condition", "cellcluster")
  colnames(lrpairs.sample) <- c("ligand", "receptor")
  rownames(countmatrix) <- toupper(rownames(countmatrix))
  lrpairs.sample$ligand <- toupper(lrpairs.sample$ligand)
  lrpairs.sample$receptor <- toupper(lrpairs.sample$receptor)

  ### logic check
  if(ncol(countmatrix) != nrow(cellinfo)) {
    stop("ncol(countmatrix) != nrow(cellinfo)")
  }

  ### sum counts by samples and cellclusters
  samples <- unique(cellinfo$sampleID)
  cellclusters <- unique(cellinfo$cellcluster)

  nsamples <- length(samples)
  No_celltypes <- length(cellclusters)

  conditions <- unlist(lapply(samples, function(ss) unique(cellinfo$condition[cellinfo$sampleID==ss])))

  sum.same.cc <- function(sampleid, ccname) {
    rowSums(countmatrix[,which(cellinfo$sampleID==sampleid & cellinfo$cellcluster==ccname)])
  }

  y <- list(sumExp=NULL, group=NULL)
  for(sampleid in samples) {
    aaa <- sapply(cellclusters, function(cc) sum.same.cc(sampleid, cc) )
    y$sumExp <- cbind(y$sumExp, aaa)
  }
  y$group <- data.frame(sampleID=rep(samples, each=No_celltypes),
                        condition=rep(conditions, each=No_celltypes),
                        cellcluster=rep(cellclusters, nsamples))

  ### remove data which will not be used in subsequent computation
  rm(countmatrix, cellinfo); gc()


  ### normalize counts and take log2( + 1)
  signal.exp <- y$sumExp
  for(i in 1:No_celltypes) {
    cell.idx <- (0:(nsamples-1))*No_celltypes + i
    dds.c <- DESeqDataSetFromMatrix(countData = y$sumExp[,cell.idx],
                                    colData = y$group[cell.idx,],
                                    design = ~ condition)
    dds.c <- estimateSizeFactors(dds.c)
    signal.exp[,cell.idx] <- log2(counts(dds.c, normalized = TRUE)+1)
  }

  ### Two sample matrices
  condition.type <- unique(y$group$condition)
  samplematrix1 <- signal.exp[,which(y$group$condition==condition.type[1])]
  samplematrix2 <- signal.exp[,which(y$group$condition==condition.type[2])]
  colnames(samplematrix1) <- y$group$cellcluster[which(y$group$condition==condition.type[1])]
  colnames(samplematrix2) <- y$group$cellcluster[which(y$group$condition==condition.type[2])]

  ### remove lr pairs which can not be found in two sample matrices
  idx.genename.nofound <- which(!(lrpairs.sample$ligand %in% rownames(samplematrix1)) |
                                  !(lrpairs.sample$receptor %in% rownames(samplematrix1)))
  if(sum(idx.genename.nofound)==0) {
    lrpairs.v2 <- lrpairs.sample
  } else {
    lrpairs.v2 <- lrpairs.sample[-c(idx.genename.nofound),]
  }
  genematrix <- data.frame(pmatch(lrpairs.v2$ligand, rownames(samplematrix1), duplicates.ok = T),
                           pmatch(lrpairs.v2$receptor, rownames(samplematrix1), duplicates.ok = T))
  genematrix <- distinct(genematrix, .keep_all= TRUE)


  #### define a genepair matrix
  genepairs <- NULL
  for (i in 1:No_celltypes) {
    for (j in 1:No_celltypes) {
      genepairs <- rbind(genepairs, cbind(i, j, genematrix))
    }
  }
  genepairs <- genepairs[,c(1,3,2,4)]


  ### Wether or not compare LR pairs with gene expression less than low.filter
  if(!is.null(low.filter)) {
    genes.exclude <- NULL
    for(i in 1:No_celltypes) {
      cell.idx <- (0:(nsamples-1))*No_celltypes + i
      idx.small <- which(rowMeans(y$sumExp[,cell.idx]) < low.filter)
      genes.exclude <- rbind(genes.exclude, cbind(rep(i,length(idx.small)), idx.small))
    }
    if(sum(genes.exclude)>0) {
      genes.exclude.connect <- paste0(genes.exclude[,1],"-",genes.exclude[,2])
      genepairs.l.connect <- paste0(genepairs[,1],"-",genepairs[,2])
      genepairs.r.connect <- paste0(genepairs[,3],"-",genepairs[,4])

      idx.genename.exclude <- which( (genepairs.l.connect %in% genes.exclude.connect) |
                                       (genepairs.r.connect %in% genes.exclude.connect)  )
      if(sum(idx.genename.exclude)>0) {
        genepairs <- genepairs[-c(idx.genename.exclude),]
      }
    }
  }

  #set.seed(2021)
  RR.all <- scXY2(samplematrix1, samplematrix2, genepairs, No_celltypes,
                  Brep, Brep0, pv0, p.filter, show.all,
                  parallel.use, cpucores, zero.impute, adjust, rhos)

  lr.cell.name <- paste0(colnames(samplematrix1)[RR.all$Rs$ligand_cell],"-",colnames(samplematrix1)[RR.all$Rs$receptor_cell])
  lr.gene.name <- paste0(rownames(samplematrix1)[RR.all$Rs$ligand_gene],"-",rownames(samplematrix1)[RR.all$Rs$receptor_gene])

  RR.all$Rs$adj.p <- round(p.adjust(as.numeric(as.character(RR.all$Rs$pvalue)), method=p.adjust.method), 12)
  RR.all$Rs$Welch.t.p[which(is.na(RR.all$Rs$Welch.t.p))] <- 1
  RR.all$Rs$adj.t.p <- round(p.adjust(as.numeric(as.character(RR.all$Rs$Welch.t.p)), method=p.adjust.method), 12)


  ### calculate adjusted p-values of using limma approach
  idx.for.limma <- as.matrix(
                              distinct(
                              data.frame(rbind(as.matrix(RR.all$Rs[,c(2,1)]), as.matrix(RR.all$Rs[, c(4,3)]))),
                              .keep_all = TRUE)
                            )
  colnames(idx.for.limma) <- c("gene", "ctype")

  adj.limma.p <- round(matrix(p.adjust(as.numeric(RR.all$pv.matrix), method=p.adjust.method),
                              nrow=nrow(RR.all$pv.matrix))[idx.for.limma], 12)
  #adj.limma.p <- round(p.adjust(as.numeric(RR.all$pv.matrix[idx.for.limma]), method=p.adjust.method), 12)
  gc.connect <- paste0(idx.for.limma[,"gene"],"-",idx.for.limma[,"ctype"])

  RR.all$Rs$adj.limma.Lg.p <- adj.limma.p[pmatch(paste0(RR.all$Rs$ligand_gene,"-",RR.all$Rs$ligand_cell), gc.connect, duplicates.ok = T)]
  RR.all$Rs$adj.limma.Rg.p <- adj.limma.p[pmatch(paste0(RR.all$Rs$receptor_gene,"-",RR.all$Rs$receptor_cell), gc.connect, duplicates.ok = T)]


  FRR2 <- cbind(lr.cell.name, lr.gene.name, RR.all$Rs[,c("obs.xy.diff", "null.diff.sd", "pvalue", "stage", "adj.p",
                                                         "Welch.t.stat", "Welch.t.sd", "Welch.t.p", "adj.t.p",
                                                         "limma.Lg.p", "limma.Rg.p", "limma.Lg.logFC", "limma.Rg.logFC",
                                                         "adj.limma.Lg.p", "adj.limma.Rg.p")
  ])

  list(Rs=FRR2,
       conditions = paste0("Condition_",1:2,": ",condition.type),
       mu.matrix1=RR.all$mu.matrix1,
       mu.matrix2=RR.all$mu.matrix2,
       sigma.matrix1=RR.all$sigma.matrix1,
       sigma.matrix2=RR.all$sigma.matrix2,
       pv.matrix=RR.all$pv.matrix,
       logFC.matrix=RR.all$logFC.matrix
       )

}

