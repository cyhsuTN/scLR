#' Test dysregulated ligand-receptor interactions at small sample sizes between multi-conditions
#' @description A function to test dysregulated ligand-receptor interactions from single cell transcriptomics
#' between multi-conditions.
#' @importFrom Matrix rowSums head tail
#' @importFrom limma lmFit eBayes
#' @importFrom stats rchisq quantile runif t.test sd bw.SJ pnorm p.adjust model.matrix weighted.mean
#' @importFrom parallel makeCluster clusterExport parApply stopCluster clusterEvalQ
#' @importFrom dplyr distinct
#' @importFrom DESeq2 DESeqDataSetFromMatrix estimateSizeFactors counts


#' @param countmatrix Input. Count matrix/dataframe with gene names.
#' @param cellinfo Input. Information for each cell, including their sampleIDs, conditions, and cell types.
#' @param lrpairs.sample  Input. A K by 2 matrix/dataframe to show names of ligand-receptor gene pairs
#' which will be compared between two samples.
#' @param low.filter Input. Pre-exclude gene pairs with the averages of gene expressions across replicates
#' less than \emph{low.filter}. The default is 1. If NULL, no LR gene pairs are pre-excluded.
#' @param p.adjust.method Input (optional). The default is "BH". Other methods include
#  "holm", "hochberg", "hommel", "bonferroni", "BH", "BY" and "fdr" (Please refer to stats::p.adjust).
#' @param Brep  Input (optional). Number of Monte-Carlo simulation replications (m). The default is 1000.
#' @param Brep0 Input (optional). Number of Monte-Carlo simulation replications in the first-stage (rough) selection.
#' The default is 200. If Brep0 = Brep, no second-stage selection.
#' @param pv0   Input (optional). Prespecified p-value in the first-stage (rough) selection.
#' The default is 0.05.
#' @param p.filter   Input (optional). The threshold, p.filter, is used to determine which ligand-receptor gene pairs
#' will not be compared. For each LR gene pair, if the average of gene expressions in one of LR genes in both samples
#' are less than the (p.filter)-quantiles of gene expressions (within same cell type),
#' the LR gene pair with the low-expressed gene will not be compared.
#' The default is 0.05.
#' @param show.all   Input (optional). A logical indicator whether or not to show
#' the results of the ligand-receptor gene pairs with lowly expressed genes. The default is FALSE,
#' showing only the results of the ligand-receptor gene pairs without lowly expressed genes.
#' @param parallel.use   Input (optional). A logical indicator whether or not to use a parallel computation.
#' The default is FALSE, i.e., a parallel computation will not be used.
#' @param cpucores   Input (optional). \emph{cpucores} CPU cores (default = 2) are used for parallel computation.
#' @param zero.impute Input (optional). A logical indicator whether zero imputation is performed or not.
#' If it is TRUE, when all the gene expressions of ligands or receptors are zeros in one sample,
#' zeros will be imputed with small non-negative values which are generated from a uniform distribution,
#' U(0, min(non-zero gene expressions)/2).
#' @param adjust Input (optional). The bandwidth h estimated by R function bw.SJ is adjusted by adjust * h.
#' The default of \emph{adjust} is 3.


#' @return \item{max.obs.xy.diff}{Maximum observed difference of mean of LR between conditions}
#' @return \item{null.diff.sd}{Standard deviation of mean difference of LR under null hypothesis}
#' @return \item{diff.stat}{obs.xy.diff is divided by null.diff.sd}
#' @return \item{pvalue}{P-value}
#' @return \item{stage}{Which stage gene pairs pass to}
#' @return \item{adj.p}{Adjusted p-value of scLR for multiple comparison}
#' @return \item{mu.matrix}{Sample means for each gene}
#' @return \item{sigma.matrix}{Posterior residual standard deviation for each gene. Assume it is the same.}

#' @examples # A simulated data to compare LR pairs between two conditions: TX1, TX2, TX3.
#' @examples # 3 replicates each condition.
#' @examples # 1000 genes and 100 cells (5 cell types, 20 cells each) for each replicate.
#' @examples # 10 ligand-receptor gene pairs across 5 cell types are compared between TX1, TX2, TX3.
#'
#' @examples set.seed(2021)
#' @examples cellinfo <- data.frame(sampleID = factor(paste0("s", rep(1:9, each=100))),
#' @examples                       condition = factor(paste0("tx", rep(1:3, each=300))),
#' @examples                       cellcluster = factor(paste0("cc", rep(rep(1:5, each=20), 9))) )
#' @examples G <- 1000; n <- 900 # 1000 genes, 900 cells
#' @examples # Data are generated from NB dist.
#' @examples NB_cell <- function(j) rnbinom(G, size = 0.1, mu = rgamma(G, shape = 2, rate = 2))
#' @examples countmatrix <- as(sapply(1:n, NB_cell),"sparseMatrix"); rownames(countmatrix) <- paste0("g", 1:1000)
#' @examples # Names of 10 ligand-receptor pairs
#' @examples lrpairs.sample <- data.frame(ligand=paste0("g", sample(1:1000, 10)),
#' @examples                             receptor=paste0("g", sample(1:1000, 10)) )
#' @examples output <- scLRmulti(countmatrix, cellinfo, lrpairs.sample, low.filter = 1)
#' @examples head(output$Rs, 20)

#' @export

scLRmulti <- function(countmatrix, cellinfo, lrpairs.sample, low.filter = 1, p.adjust.method = "BH",
                  Brep = 1000, Brep0 = 200, pv0 = 0.05, p.filter = 0.05, show.all = FALSE,
                  parallel.use = FALSE, cpucores = 2, zero.impute = TRUE, adjust = 3) {

  colnames(cellinfo) <- c("sampleID", "condition", "cellcluster")
  colnames(lrpairs.sample) <- c("ligand", "receptor")
  rownames(countmatrix) <- toupper(rownames(countmatrix))
  lrpairs.sample$ligand <- toupper(lrpairs.sample$ligand)
  lrpairs.sample$receptor <- toupper(lrpairs.sample$receptor)

  ### logic check
  if(ncol(countmatrix) != nrow(cellinfo)) {
    stop("ncol(countmatrix) != nrow(cellinfo)")
  }

  ### sum counts by cellclusters for each sample
  samples <- unique(cellinfo$sampleID)
  cellclusters <- unique(cellinfo$cellcluster)

  nsamples <- length(samples)
  No_celltypes <- length(cellclusters)

  conditions <- unlist(lapply(samples, function(ss) unique(cellinfo$condition[cellinfo$sampleID==ss])))

  sum.same.cc <- function(sampleid, ccname) {
    rowSums(countmatrix[,which(cellinfo$sampleID==sampleid & cellinfo$cellcluster==ccname)]) #### What if NA exists ####
  }

  y <- list(sumExp=NULL, group=NULL)
  for(sampleid in samples) {
    aaa <- sapply(cellclusters, function(cc) sum.same.cc(sampleid, cc) )
    y$sumExp <- cbind(y$sumExp, aaa)
  }
  y$group <- data.frame(sampleID=rep(samples, each=No_celltypes),
                        condition=rep(conditions, each=No_celltypes),
                        cellcluster=rep(cellclusters, nsamples))

  ### remove data which will not be used in subsequent computation
  rm(countmatrix, cellinfo); gc()


  ### normalize counts and take log2( + 1)
  signal.exp <- y$sumExp
  for(i in 1:No_celltypes) {
    cell.idx <- (0:(nsamples-1))*No_celltypes + i
    dds.c <- DESeqDataSetFromMatrix(countData = y$sumExp[,cell.idx],
                                    colData = y$group[cell.idx,],
                                    design = ~ condition)
    dds.c <- estimateSizeFactors(dds.c)
    signal.exp[,cell.idx] <- log2(counts(dds.c, normalized = TRUE) + 1)
  }


  ### remove lr pairs which can not be found in dataset
  idx.genename.nofound <- which(!(lrpairs.sample$ligand %in% rownames(signal.exp)) |
                                  !(lrpairs.sample$receptor %in% rownames(signal.exp)))
  if(sum(idx.genename.nofound)==0) {
    lrpairs.v2 <- lrpairs.sample
  } else {
    lrpairs.v2 <- lrpairs.sample[-c(idx.genename.nofound),]
  }
  genematrix <- data.frame(pmatch(lrpairs.v2$ligand, rownames(signal.exp), duplicates.ok = T),
                           pmatch(lrpairs.v2$receptor, rownames(signal.exp), duplicates.ok = T))
  genematrix <- distinct(genematrix, .keep_all= TRUE)


  #### define a genepair matrix
  genepairs <- NULL
  for (i in 1:No_celltypes) {
    for (j in 1:No_celltypes) {
      genepairs <- rbind(genepairs, cbind(i, j, genematrix))
    }
  }
  genepairs <- genepairs[,c(1,3,2,4)]



  ### Samples stratified by multi-conditions
  condition.type <- unique(y$group$condition)
  smatrix <- lapply(condition.type, function(x) {
    samplematrix <- signal.exp[,which(y$group$condition==x)]
    colnames(samplematrix) <- y$group$cellcluster[which(y$group$condition==x)]
    samplematrix
  })
  names(smatrix) <- condition.type


  ### Wether or not compare LR pairs with gene expression less than low.filter
  if(!is.null(low.filter)) {
    genes.exclude <- NULL
    for(i in 1:No_celltypes) {
      cell.idx <- (0:(nsamples-1))*No_celltypes + i
      idx.small <- which(rowMeans(y$sumExp[,cell.idx]) < low.filter)
      genes.exclude <- rbind(genes.exclude, cbind(rep(i,length(idx.small)), idx.small))
    }
    if(sum(genes.exclude)>0) {
      genes.exclude.connect <- paste0(genes.exclude[,1],"-",genes.exclude[,2])
      genepairs.l.connect <- paste0(genepairs[,1],"-",genepairs[,2])
      genepairs.r.connect <- paste0(genepairs[,3],"-",genepairs[,4])

      idx.genename.exclude <- which( (genepairs.l.connect %in% genes.exclude.connect) |
                                       (genepairs.r.connect %in% genes.exclude.connect)  )
      if(sum(idx.genename.exclude)>0) {
        genepairs <- genepairs[-c(idx.genename.exclude),]
      }
    }
  }




  set.seed(2021)
  RR.all <- scXYmulti(smatrix, genepairs, No_celltypes,
                  Brep, Brep0, pv0, p.filter, show.all,
                  parallel.use, cpucores, zero.impute, adjust)
  #head(RR.all$Rs)


  lr.cell.name <- paste0(cellclusters[RR.all$Rs$ligand_cell],"-",cellclusters[RR.all$Rs$receptor_cell])
  lr.gene.name <- paste0(rownames(smatrix[[1]])[RR.all$Rs$ligand_gene],"-",rownames(smatrix[[1]])[RR.all$Rs$receptor_gene])

  RR.all$Rs$adj.p <- round(p.adjust(as.numeric(as.character(RR.all$Rs$pvalue)), method=p.adjust.method), 12)
  #RR.all$Rs$Welch.t.p[which(is.na(RR.all$Rs$Welch.t.p))] <- 1
  #RR.all$Rs$adj.t.p <- round(p.adjust(as.numeric(as.character(RR.all$Rs$Welch.t.p)), method=p.adjust.method), 12)

  FRR2 <- cbind(lr.cell.name, lr.gene.name, RR.all$Rs[,c("max.obs.xy.diff", "null.diff.sd", "pvalue", "stage", "adj.p"
                                                         #"Welch.t.stat", "Welch.t.sd", "Welch.t.p", "adj.t.p"
  )])

  list(Rs=FRR2,
       conditions = paste0("Condition_",1:length(smatrix),": ",condition.type),
       mu.matrix=RR.all$mu.matrix,
       sigma.matrix=RR.all$sigma.matrix)

}





scXYmulti <- function(smatrix, genepairs, No_celltypes,
                      Brep = 1000, Brep0 = 200, pv0 = 0.05, p.filter = 0.05, show.all = FALSE,
                      parallel.use = FALSE, cpucores = 2, zero.impute = TRUE, adjust = 3) {

  mu.matrix <- sigma.matrix <- lapply(1:length(smatrix), function(x) {
    matrix(NA, nrow = nrow(smatrix[[1]]), ncol = No_celltypes)
  })
  Ns <- lapply(smatrix, function(x) ncol(x)/No_celltypes)
  const <- lapply(Ns, function(x) (0:(x - 1)) * No_celltypes)

  set.seed(2021)
  for (k in 1:No_celltypes) {

    ### zero imputation
    if(zero.impute) {
      for(cc in 1:length(smatrix)) {
        minval <- min(smatrix[[cc]][smatrix[[cc]]>0], na.rm = T)/2
        idx.col <- k + const[[cc]]
        idx.allzero <- which(rowSums(smatrix[[cc]][, idx.col])==0)
        smatrix[[cc]][idx.allzero, idx.col] <- runif(length(idx.allzero)*Ns[[cc]], 0, minval)
      }
    }

    ### run limma
    yy <- NULL
    for(cc in 1:length(smatrix)) {
      idx.col <- k + const[[cc]]
      yy <- cbind(yy, smatrix[[cc]][, idx.col])
    }
    designmatrix <- model.matrix(~ factor(rep(1:length(smatrix), unlist(Ns))))

    fit0 <- lmFit(yy, designmatrix)
    fit0 <- eBayes(fit0)

    ### estimates of coefficients and sd
    for(cc in 1:length(smatrix)) {

      sigma.matrix[[cc]][,k] <- sqrt(fit0$s2.post)

      if(cc==1) {
        mu.matrix[[cc]][, k] <- as.numeric(fit0$coefficients[,1])
      } else {
        mu.matrix[[cc]][, k] <- as.numeric(fit0$coefficients[,1] + fit0$coefficients[,cc])
      }
    }

  }


  comparefun <- function(pair) {

    #pair <- genepairs[1,]
    pair <- as.numeric(pair)
    XY <- lapply(1:length(smatrix), function(cc) {
      smatrix[[cc]][pair[2], pair[1]+const[[cc]]] * smatrix[[cc]][pair[4], pair[3]+const[[cc]]]
    })

    ns <- sapply(1:length(smatrix), function(cc) {
      sum(!is.na(XY[[cc]]))
    })

    obs.xy.mean <- sapply(XY, mean, na.rm=T)
    max.obs.xy.diff <- max(obs.xy.mean) - min(obs.xy.mean)


    muv <- lapply(mu.matrix, function(x) c(x[pair[2], pair[1]], x[pair[4], pair[3]]))
    sigmav <- lapply(sigma.matrix, function(x) c(x[pair[2], pair[1]], x[pair[4], pair[3]]))
    rhov <- rep(0, length(smatrix))

    sigma.prod <- sapply(sigmav, prod)


    av <- sapply(1:length(smatrix), function(cc) {
      sum(muv[[cc]]/sigmav[[cc]])^2/(2*(1+rhov[cc]))
    })

    bv <- sapply(1:length(smatrix), function(cc) {
      diff(muv[[cc]]/sigmav[[cc]])^2/(2*(1-rhov[cc]))
    })
    a.bar <- weighted.mean(av, w=ns)
    b.bar <- weighted.mean(bv, w=ns)
    sigma.prod.bar <- weighted.mean(sigma.prod, w=ns)
    rho.bar <- weighted.mean(rhov, w=ns)

    nsum <- sum(ns)
    xy.mean.diff.null <- function(nsum, sigma.prod.bar, a.bar, b.bar, rho.bar) {
      xy <- 0.25*sigma.prod.bar*(2*(1+rho.bar)*rchisq(nsum, df=1, ncp=a.bar) -
                                   2*(1-rho.bar)*rchisq(nsum, df=1, ncp=b.bar))

      xy.mean <- as.numeric(sapply(split(xy, rep(1:length(smatrix), ns)), mean))
      max(xy.mean) - min(xy.mean)
    }

    set.seed(200)
    Ts0 <- replicate(Brep0, xy.mean.diff.null(nsum, sigma.prod.bar, a.bar, b.bar, rho.bar))
    pvalue0 <- mean(Ts0 > max.obs.xy.diff, na.rm=T)

    if (pvalue0 < pv0 & Brep0 < Brep) {
      Ts <- c(replicate(Brep-Brep0, xy.mean.diff.null(nsum, sigma.prod.bar, a.bar, b.bar, rho.bar)), Ts0)

      bw <- bw.SJ(c(Ts,-Ts), nb=1000, method = c("ste")) * adjust # same as kde <- density(c(Ts,-Ts), bw="SJ", adjust=adjust); kde$bw
      tailprob <- mean(pnorm( max.obs.xy.diff - c(Ts,-Ts), 0, bw))
      pvalue <- ifelse(tailprob < 0.5, 2 * tailprob, 2 * (1 - tailprob))

      null.diff.sd <- sd(Ts)
      diff.stat <- max.obs.xy.diff/null.diff.sd
      stage <- 2
      c(max.obs.xy.diff = round(max.obs.xy.diff,4), null.diff.sd = round(null.diff.sd,4), diff.stat = round(diff.stat,4),
        pvalue = round(pvalue,12), stage = stage)
    } else {
      null.diff.sd <- sd(Ts0)
      diff.stat <- max.obs.xy.diff/null.diff.sd
      stage <- 1
      c(max.obs.xy.diff = round(max.obs.xy.diff,4), null.diff.sd = round(null.diff.sd,4), diff.stat = round(diff.stat,4),
        pvalue = pvalue0, stage = stage)
    }


  }

  genepairs2 <- genepairs
  colnames(genepairs2) <- c("ligand_cell", "ligand_gene", "receptor_cell", "receptor_gene")

  ### parallel computation
  if (parallel.use) {
    cl <- makeCluster(cpucores)
    clusterEvalQ(cl, set.seed(2021))
    clusterExport(cl, varlist = c("smatrix",
                                  "mu.matrix",
                                  "sigma.matrix",
                                  #"threshold1", "threshold2",
                                  "adjust",
                                  "const",
                                  "Brep", "Brep0", "pv0"), envir = environment())
    Rs <- cbind(genepairs2, data.frame(t(parApply(cl, genepairs, 1, comparefun))))
    stopCluster(cl)
  } else {
    set.seed(2021)
    Rs <- cbind(genepairs2, data.frame(t(apply(genepairs, 1, comparefun))))
  }

  if (!show.all) {
    Rs <- Rs[Rs$stage %in% c(1,2),]
    Rs$pvalue <- as.numeric(as.character(Rs$pvalue))
    Rs$obs.xy.diff <- as.numeric(as.character(Rs$max.obs.xy.diff))
    Rs$null.diff.sd <- as.numeric(as.character(Rs$null.diff.sd))
    Rs$diff.stat <- as.numeric(as.character(Rs$diff.stat))
    Rs$pvalue <- as.numeric(as.character(Rs$pvalue))
  }
  list(Rs=Rs,
       mu.matrix=mu.matrix,
       sigma.matrix=sigma.matrix)


}

